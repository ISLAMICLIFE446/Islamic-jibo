# ইসলামীক জীবন — মোবাইল দিয়ে বিল্ড করার নির্দেশনা

এটি Flutter সোর্স প্রজেক্ট; সরাসরি APK নয়।

## এই সংস্করণে কী আছে
- বাংলা UI ও নেভিগেশন
- হোম ড্যাশবোর্ড
- দৈনিক আমল রিপোর্ট: ৫ ওয়াক্ত সালাত, আয়াত সংখ্যা, আত্মীয়তার হক, তাওবা; SharedPreferences-এ লোকাল সেভ
- ব্যক্তিগত নোটবুক: নোট যোগ/মুছুন, লোকাল সেভ
- কুরআন, দোয়া, হাদিস, ক্যালেন্ডার ও নামাজের সময়ের জন্য প্রাথমিক স্ক্রিন

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এই সোর্সে এখনো যাচাইকৃত পূর্ণ কুরআন/অনুবাদ/চার তাফসির, ৩০০ দোয়া, চার হাদিসগ্রন্থ, লাইভ নামাজের সময়, আজান অ্যালার্ম, বাংলা-হিজরি ক্যালেন্ডার, ক্লাউড সিঙ্ক বা পূর্ণ ব্যাকএন্ড নেই। স্ক্রিনে নমুনা/ডেটা-সংযুক্তির বার্তা দেখানো হয়েছে। কপিরাইটযুক্ত তাফসির/অনুবাদ/হাদিস সংস্করণ প্রকাশের আগে লাইসেন্স/অনুমতি নিতে হবে।

## মোবাইল দিয়ে কাজের সাধারণ ধাপ
1. ZIP-টি ফোনে Extract করুন অথবা GitHub-এ নতুন repository তৈরি করে ফাইলগুলো upload করুন।
2. GitHub-এ repository public/private যেভাবে চান সেট করুন। Play Store public হবে কি না, সেটি আলাদা সিদ্ধান্ত।
3. Codemagic (https://codemagic.io/) এ অ্যাকাউন্ট খুলে GitHub repository সংযুক্ত করুন।
4. Flutter project হিসেবে Android build চালান; release signing key/credentials নিরাপদে configure করতে হবে।
5. Play Console-এ AAB upload করে store listing, privacy policy, data safety, content rating, testing এবং release checklist সম্পন্ন করুন। Google-এর বর্তমান account-specific testing শর্ত Play Console-এ যাচাই করুন।
6. iOS build-এর জন্য Codemagic-এ Apple Developer account, App Store Connect API key/certificates/provisioning profile configure করতে হবে। তারপর App Store Connect-এ submit করুন।

## স্থানীয়ভাবে চালাতে
Flutter SDK স্থাপন করে project folder-এ:
```bash
flutter pub get
flutter run
```

## Android release bundle
```bash
flutter build appbundle --release
```

## iOS
macOS/Xcode অথবা macOS cloud build environment প্রয়োজন।

## নিরাপত্তা
Signing key, passwords, API keys কখনো GitHub repository-তে commit করবেন না।
