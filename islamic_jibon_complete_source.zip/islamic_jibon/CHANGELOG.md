# Changelog

## 0.2.0
- Refined Bengali app shell and feature pages.
- Added locally persisted daily routine report and personal notebook via shared_preferences.
- Added phone-first cloud build and store publishing notes.
- Quran, tafsir, hadith, dua, prayer-time, alarm and calendar datasets/services remain to be integrated and validated.
